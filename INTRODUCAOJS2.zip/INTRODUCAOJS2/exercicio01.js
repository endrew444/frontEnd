//1. criar um contador
for(let i =1; i<=100; i++){
    console.log(i)
}

//verificar se um numero é par ou impar
var prompt = require("prompt-sync")();
var numero;
numero = prompt("Digite um número:");
if (numero%2==0) {
    console.log("par");
} else {
    console.log("Impar");
}



